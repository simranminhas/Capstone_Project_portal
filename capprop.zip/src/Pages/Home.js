import React from "react";

const Home = () => {
    return (
        <div className="page">
            <p>welcome to home</p>
        </div>
    )
}

export default Home