import React from "react";

const PageNotFound = () => {
  return (
    <div className="page">
      <h1> PageNotFound Page</h1>
    </div>
  );
};

export default PageNotFound;
