import React from "react";

const List = () => {
    return (<div className="page">
        <h1>Welcome to List page</h1>

        <h3>this page will display list of all students who a under the mentorship of the specific teacher</h3>
    </div>);
    
};

export default List;
